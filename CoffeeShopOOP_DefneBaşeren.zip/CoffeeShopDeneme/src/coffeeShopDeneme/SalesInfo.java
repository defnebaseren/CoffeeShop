package coffeeShopDeneme;

public class SalesInfo {
	
	int productNo;
	String consumerPhoneNumber;
		

	public String getConsumerPhoneNumber() {
		return consumerPhoneNumber;
	}

	public void setConsumerPhoneNumber(String consumerPhoneNumber) {
		this.consumerPhoneNumber = consumerPhoneNumber;
	}

	public int getProductNo() {
		return productNo;
	}

	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}
	
	
}
