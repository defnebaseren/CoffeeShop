package coffeeShopDeneme;

public interface CampaignsDal {

	void newCampaign();
	void updateCampaign();
	void deleteCampaign();
}
