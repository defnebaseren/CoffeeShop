package coffeeShopDeneme;

public class NeroConsumerDal implements ConsumerDal {

	@Override
	public void addConsumer() {
		
		System.out.println("New Nero consumer has been added.");
		
	}

	@Override
	public void updateConsumer() {
		
		System.out.println("Nero consumer info has been updated.");
		
	}

	@Override
	public void deleteConsumer() {
		
		System.out.println("New Nero consumer has been deleted.");
		
	}


}
