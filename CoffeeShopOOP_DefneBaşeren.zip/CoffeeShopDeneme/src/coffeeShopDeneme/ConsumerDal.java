package coffeeShopDeneme;

public interface ConsumerDal {
	
	void addConsumer();
	void updateConsumer();
	void deleteConsumer();

}
