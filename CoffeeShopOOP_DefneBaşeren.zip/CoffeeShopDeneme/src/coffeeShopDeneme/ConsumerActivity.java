package coffeeShopDeneme;

public class ConsumerActivity implements IConsumerActivity{

	ConsumerDal consumerDal;
	
	
	public ConsumerActivity(ConsumerDal consumerDal) {
		super();
		this.consumerDal = consumerDal;
	}

	
	@Override
	public void addConsumer(ConsumerInfo consumerInfo) {
		
	}

	@Override
	public void updateConsumer(ConsumerInfo consumerInfo) {
		
	}

	@Override
	public void deleteConsumer(ConsumerInfo consumerInfo) {
		
	}

	
}
