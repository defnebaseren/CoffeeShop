package coffeeShopDeneme;

public abstract interface ICampaignActivity{
	void newCampaign(CampaignsInfo campaignsInfo);
	void updateCampaign(CampaignsInfo campaignsInfo);
	void deleteCampaign(CampaignsInfo campaignsInfo);

}
