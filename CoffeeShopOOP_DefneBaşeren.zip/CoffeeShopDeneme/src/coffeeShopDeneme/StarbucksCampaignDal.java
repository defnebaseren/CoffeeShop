package coffeeShopDeneme;

public class StarbucksCampaignDal implements CampaignsDal {

	@Override
	public void newCampaign() {
		
		System.out.println("New Starbucks campaign is added.");
		
	}

	@Override
	public void updateCampaign() {
		
		System.out.println("Starbucks campaign is updated.");
		
	}

	@Override
	public void deleteCampaign() {
		
		System.out.println("Starbucks campaign is deleted.");
		
	}

}
