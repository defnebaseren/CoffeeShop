package coffeeShopDeneme;

public class EdevletCheckActivity {
	
	
	ConsumerDal consumerDal;

	public EdevletCheckActivity(ConsumerDal consumerDal) {
		this.consumerDal = consumerDal;
	}
	
	public void checkEdevlet(ConsumerInfo consumerInfo) {
		if (consumerInfo.tcNo == 1004546 && consumerInfo.firstName == "Jane" && consumerInfo.lastName == "Doe" && consumerInfo.birthDate == "10.07.1995)"); //database içindeki unique tcNo'ya takbul eden değerleri değerlendirmesi lazım
	
		System.out.println("Consumer info is correct.");
		return;

	}
}
