package coffeeShopDeneme;

public abstract interface IConsumerActivity {
	void addConsumer(ConsumerInfo consumerInfo);
	void updateConsumer(ConsumerInfo consumerInfo);
	void deleteConsumer(ConsumerInfo consumerInfo);

}
