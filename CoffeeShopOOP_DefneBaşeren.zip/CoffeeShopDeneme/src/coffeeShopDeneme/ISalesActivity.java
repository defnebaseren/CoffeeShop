package coffeeShopDeneme;

public abstract interface ISalesActivity{
	void updateSalesInfo(SalesInfo salesInfo, CampaignsInfo campaignsInfo , ConsumerInfo consumerInfo);
	void deleteSalesInfo(SalesInfo salesInfo, CampaignsInfo campaignsInfo , ConsumerInfo consumerInfo);

}
