package coffeeShopDeneme;

public interface SalesDal {

	void updateSalesInfo();
	void deleteSalesInfo();
}
