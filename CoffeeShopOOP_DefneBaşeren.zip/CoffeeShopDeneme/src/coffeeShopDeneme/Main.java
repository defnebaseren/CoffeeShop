package coffeeShopDeneme;

public class Main {

	public static void main(String[] args) {
		ConsumerActivity consumerActivity = new ConsumerActivity (new NeroConsumerDal());
		ConsumerInfo consumerInfo = new ConsumerInfo();
		//ÖRNEĞİN
		consumerInfo.setTcNo(1004046);
		consumerInfo.setFirstName("Jane");
		consumerInfo.setLastName("Doe");
		consumerInfo.setBirthDate("10.07.1995");
		consumerInfo.setPhoneNumber("0532000000");
		
		consumerActivity.addConsumer(consumerInfo);
	}
	//STARBUCKS MÜŞTERİSİ İÇİN YAPIYOR OLSAYDIK:
	
	//public static void main(String args5 , String args6) {
		//EdevletCheckActivity edevletCheckActivity = new EdevletCheckActivity (new StarbucksConsumerDal());
		//ConsumerInfo consumerInfo = new ConsumerInfo();
		
		//consumerInfo.setTcNo(1004046);
		//consumerInfo.setFirstName("Jane");
		//consumerInfo.setLastName("Doe");
		//consumerInfo.setBirthDate("10.07.1995");
		
		//edevletCheckActivity.checkEdevlet(consumerInfo);
	//}
	
	public static void main(String args1) {
		CampaignActivity campaignActivity = new CampaignActivity(new NeroCampaignsDal());
		CampaignsInfo campaignsInfo = new CampaignsInfo();
		//ÖRNEĞİN
		campaignsInfo.setStartingDate("25.01.2021");
		campaignsInfo.setEndingDate("25.02.2021");
		campaignsInfo.setProductNo(17);
		campaignsInfo.setPercentageDiscount(50);
		
		campaignActivity.newCampaign(campaignsInfo);
			
	}
	
	public static void main(String args2 , String args3 , String args4) {
		SalesActivity salesActivity = new SalesActivity(new NeroSalesDal(),new NeroConsumerDal(), new NeroCampaignsDal());
		SalesInfo salesInfo = new SalesInfo();
		//ÖRNEĞİN
		salesInfo.setConsumerPhoneNumber("0532000000");
		salesInfo.setProductNo(17);

		
		salesActivity.updateSalesInfo(salesInfo, null, null);
		

	}
	
}

