package coffeeShopDeneme;

public class NeroConsumerInfo extends ConsumerInfo {

}
