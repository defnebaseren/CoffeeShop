package coffeeShopDeneme;

public class NeroCampaignsDal implements CampaignsDal {

	@Override
	public void newCampaign() {
		
		System.out.println("New Nero campaign is added.");
		
	}

	@Override
	public void updateCampaign() {
		
		System.out.println("Nero campaign is updated.");
		
	}

	@Override
	public void deleteCampaign() {
	
		System.out.println("Nero campaign is deleted.");
		
	}

}
