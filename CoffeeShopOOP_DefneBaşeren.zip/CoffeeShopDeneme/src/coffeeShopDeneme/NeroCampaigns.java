package coffeeShopDeneme;

public class NeroCampaigns extends CampaignsInfo{

}
