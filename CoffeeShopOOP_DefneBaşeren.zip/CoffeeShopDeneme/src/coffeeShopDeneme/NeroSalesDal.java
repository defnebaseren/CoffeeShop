package coffeeShopDeneme;

public class NeroSalesDal implements SalesDal {

	@Override
	public void updateSalesInfo() {
		System.out.println("Sales info for Nero customer is updated.");
	}

	@Override
	public void deleteSalesInfo() {
		System.out.println("Sales info for Nero customer is deleted.");
		
	}

}
