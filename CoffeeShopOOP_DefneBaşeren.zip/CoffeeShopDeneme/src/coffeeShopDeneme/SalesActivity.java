package coffeeShopDeneme;

public class SalesActivity implements ISalesActivity {
	
	SalesDal salesDal;
	ConsumerDal consumerDal;
	CampaignsDal campaignsDal;
	public SalesActivity(SalesDal salesDal, ConsumerDal consumerDal, CampaignsDal campaignsDal) {
		super();
		this.salesDal = salesDal;
		this.consumerDal = consumerDal;
		this.campaignsDal = campaignsDal;
	}
	
	@Override
	public void updateSalesInfo(SalesInfo salesInfo, CampaignsInfo campaignsInfo, ConsumerInfo consumerInfo) {
			if(salesInfo.productNo == campaignsInfo.productNo && salesInfo.consumerPhoneNumber == consumerInfo.phoneNumber);
			System.out.println("Updated with related customer and campaign info");
				if (salesInfo.consumerPhoneNumber == consumerInfo.phoneNumber);
				System.out.println("Updated with only the related customer info. No related campaign found.");
				return;
		
	}

	@Override
	public void deleteSalesInfo(SalesInfo salesInfo, CampaignsInfo campaignsInfo ,ConsumerInfo consumerInfo){
		if(salesInfo.productNo == campaignsInfo.productNo);
			System.out.println("Deleted with related customer and campaign info");
			if (salesInfo.consumerPhoneNumber == consumerInfo.phoneNumber);
			System.out.println("Deleted with only the related customer info. No related campaign found.");
			return;
		
	}

	
}

