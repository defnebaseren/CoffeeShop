package coffeeShopDeneme;

public class StarbucksSales extends SalesInfo {

	}


