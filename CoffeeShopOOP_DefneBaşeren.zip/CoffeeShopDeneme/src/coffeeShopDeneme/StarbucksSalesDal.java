package coffeeShopDeneme;

public class StarbucksSalesDal implements SalesDal{


	@Override
	public void updateSalesInfo() {
		System.out.println("Sales info for Starbucks customer is updated.");
		
	}

	@Override
	public void deleteSalesInfo() {
		System.out.println("Sales info for Starbucks customer is deleted.");
	}
	
	

}

