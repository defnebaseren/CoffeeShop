package coffeeShopDeneme;

public class NeroSales extends SalesInfo {

	}


