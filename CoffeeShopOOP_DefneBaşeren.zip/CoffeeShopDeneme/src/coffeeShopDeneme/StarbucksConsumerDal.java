package coffeeShopDeneme;

public class StarbucksConsumerDal implements ConsumerDal {
	
	public void checkEdevlet() {
		
	}

	@Override
	public void addConsumer() {
		
		System.out.println("New Starbucks consumer has been added.");
		
	}

	@Override
	public void updateConsumer() {
		
		System.out.println("Starbucks consumer info has been updated.");
		
	}

	@Override
	public void deleteConsumer() {
		
		System.out.println("Starbucks consumer has been deleted.");
	}

}
