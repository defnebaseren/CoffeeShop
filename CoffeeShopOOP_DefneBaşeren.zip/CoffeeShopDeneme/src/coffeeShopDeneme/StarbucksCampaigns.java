package coffeeShopDeneme;

public class StarbucksCampaigns extends CampaignsInfo {

}
