package coffeeShopDeneme;

public class CampaignActivity implements ICampaignActivity {

	CampaignsDal campaignsDal;
	
	
	public CampaignActivity(CampaignsDal campaignsDal) {
		super();
		this.campaignsDal = campaignsDal;
	}

	@Override
	public void newCampaign(CampaignsInfo campaignsInfo) {
		
	}

	@Override
	public void updateCampaign(CampaignsInfo campaignsInfo) {
		
	}

	@Override
	public void deleteCampaign(CampaignsInfo campaignsInfo) {
		
	}

	
}
