package coffeeShopDeneme;

public class StarbucksConsumerInfo extends ConsumerInfo{

	
}
